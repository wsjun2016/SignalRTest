﻿using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using MyProject.Entity;

namespace SignalRTest.Utils {
    [HubName("groupChatHub")]
    public class GroupChatHub:Hub {

        private string Pic {
            get {
                var pic = Context.RequestCookies[TLogin.USERINFO];
                return pic == null ? "" : LitJson.JsonMapper.ToObject(HttpUtility.UrlDecode(pic.Value))["Pic"].ToString();
            }
        }
        /// <summary>
        /// 用户名 
        /// </summary>
        private string UserName {
            get {
                var userName = Context.RequestCookies[TLogin.USERINFO];
                return userName == null ? "" : LitJson.JsonMapper.ToObject(HttpUtility.UrlDecode(userName.Value))["Name"].ToString();
            }
        }

        //创建聊天的房间
        public void CreationRoom(string roomId) {
            try {
                // 加入Hub Group，为了发送单独消息
                Groups.Add(Context.ConnectionId, "GROUP-" + roomId);
            }
            catch (Exception ex) {

            }
        }

        /// <summary>
        /// 在线用户
        /// </summary>
        private static Dictionary<string, int> _onlineUser = new Dictionary<string, int>();

        public override Task OnConnected() {
            Connected();
            return base.OnConnected();
        }

        public override Task OnReconnected() {
            Connected();
            return base.OnReconnected();
        }

        private void Connected() {
            var tmp = Context.Request.QueryString["sid"] ?? "";


            //处理在线人员
            //如果名称不存在，则是新用户
            if (!_onlineUser.ContainsKey(UserName) ) {
                _onlineUser.Add(UserName, 1);

                //向客户端发送在线人员
                Clients.All.publishUser(_onlineUser.Select(i => i.Key));

                //向客户端发送新加入人员信息
                Clients.All.publishMsg(FormatMsg("系统消息", UserName + "  加入聊天",0));
            }
            else {
                // 如果是已经存在的用户，则把在线链接的个数+1
                _onlineUser[UserName] = _onlineUser[UserName] + 1;
            }

            // 加入Hub Group，为了发送单独消息
            Groups.Add(Context.ConnectionId, "GROUP-" + UserName);

        }

        public override Task OnDisconnected(bool stopCalled) {
            //人员连接数减1
            _onlineUser[UserName] = _onlineUser[UserName] - 1;
            if (_onlineUser[UserName] == 0) {
                // 移除在线人员
                _onlineUser.Remove(UserName);
                // 向客户端发送在线人员
                Clients.All.publishUser(_onlineUser.Select(i=>i.Key));
                // 向客户端发送退出聊天消息
                Clients.All.publishMsg(FormatMsg("系统消息",UserName+ "  退出聊天", 0));
            }
            // 移除Hub Group
            Groups.Remove(Context.ConnectionId,"GROUP-"+UserName);

            return base.OnDisconnected(stopCalled);
        }

        /// <summary>
        /// 发送消息，供客户端调用
        /// </summary>
        /// <param name="user">用户名，如果为0，则是发送给所有人</param>
        /// <param name="msg">消息</param>
        public void SendMsg(string user,string msg) {
            if (user == "0") {
                Clients.All.publishMsg(FormatMsg(UserName, msg,1, Pic));
            }
            else {
                Clients.Groups(new List<string> { "GROUP-" + UserName, "GROUP-" + user }).publishMsg(FormatMsg(UserName, msg,1,Pic));
            }
        }

        //type 0:系统消息 1:用户消息
        public dynamic FormatMsg(string name, string msg, int type=1,string pic="") {
            return new {IType=type, Name=name,Msg=HttpUtility.HtmlEncode(msg),Pic= HttpUtility.HtmlEncode(pic), Time=DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")};
        }
    }
}